This example shows how, with just changing the function name, you can send your training job to us. 

You can check the status of your jobs on the cloud based on your API key. 

To get your API key, please get in touch with us! 