# Simplifine

Welcome to Simplifine! This is an easy-to-use library that provides tools for training classifiers, fine-tuning language models, and embedding models with contrastive learning.